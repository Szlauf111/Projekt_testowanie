import React, { useState, useEffect } from "react";

import "./App.css";
import TaskForm from "./components/TaskForm";
import TaskColumn from "./components/TaskColumn";

// Pobieranie zadam z localStorage
const oldTasks = localStorage.getItem("tasks");


const App = () => {
  const [tasks, setTasks] = useState(JSON.parse(oldTasks) || []);

  // zapisywanie
  useEffect(() => {
    localStorage.setItem("tasks", JSON.stringify(tasks));
  }, [tasks]);

  // usuwanie
  const handleDelete = (taskIndex) => {
    // Filtrowanie zadan
    const newTasks = tasks.filter((task, index) => index !== taskIndex);
    // Aktualizacja stanu tasks
    setTasks(newTasks);
  };

  return (
  
    <div className="app">
      {/*formularz do dodawania */}
      <TaskForm setTasks={setTasks} />
      {/* kolumna z zadaniami */}
      <main className="app_main">
        {/* kolumna z zadaniami do zrobienia */}
        <TaskColumn
          title="Do zrobienia"
          tasks={tasks}
          status="todo"
          handleDelete={handleDelete}
        />
        {/* do zrealizowania */}
        <TaskColumn
          title="Robione"
          tasks={tasks}
          status="doing"
          handleDelete={handleDelete}
        />
      {/* zadania ukonczone */}
        <TaskColumn
          title="Zrobione"
          tasks={tasks}
          status="done"
          handleDelete={handleDelete}
        />
      </main>
    </div>
  );
};

export default App;