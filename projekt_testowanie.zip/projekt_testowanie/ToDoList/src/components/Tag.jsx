import React from "react";

import "./Tag.css";

//Definiowanie Tagu
const Tag = ({ tagName, selectTag, selected }) => {
    // style dla tagow
    const tagStyle = {
        HTML: { backgroundColor: "#fda821" },
        CSS: { backgroundColor: "#4cdafc" },
        JavaScript: { backgroundColor: "#ffd12c" },
        React: { backgroundColor: "#00da91" },
        default: { backgroundColor: "#f9f9f9" },
    };
    return (

        // guzik dla tagu
        <button
            type='button'
            className='tag'
            style={selected ? tagStyle[tagName] : tagStyle.default}
            // efekt wklikniecia
            onClick={() => selectTag(tagName)}>
            {tagName}
        </button>
    );
};

export default Tag;
