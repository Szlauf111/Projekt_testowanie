import React, { useState } from "react";


import "./TaskForm.css";
import Tag from "./Tag";


const TaskForm = ({ setTasks }) => {
  // ustawienia pamieci na serwerze
  const [taskData, setTaskData] = useState({
    task: "",
    status: "todo",
    tags: [],
  });

  // wyswietlanie w konsoli
  console.log("Task Data :", taskData);

  // Funkcja sprawdzajaca czy tag jest wybrany
  const checkTag = (tag) => {
    return taskData.tags.some((item) => item === tag);
  };

  // Funkcja do wybierania/odznaczania tagu
  const selectTag = (tag) => {
    if (taskData.tags.some((item) => item === tag)) {
      // Jesli tag jest juz wybrany, jest usuwany z listy tagow  
          const filterTags = taskData.tags.filter((item) => item !== tag);
      setTaskData((prev) => {
        return { ...prev, tags: filterTags };
      });
    } else {
      // Jesli tag nie zosatal jest wybrany, tutaj jest dodawany ponownie
      setTaskData((prev) => {
        return { ...prev, tags: [...prev.tags, tag] };
      });
    }
  };

  // zmiana wartosci pol formularza
  const handleChange = (e) => {
    const { name, value } = e.target;

    setTaskData((prev) => {
      return { ...prev, [name]: value };
    });
  };

  // zapisuje dane z formularzu
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(taskData);
    setTasks((prev) => {
      return [...prev, taskData];
    });
    // Resetowanie taskData
    setTaskData({
      task: "",
      status: "todo",
      tags: [],
    });
  };

  return (
    
    <header className="app_header">
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="task"
          value={taskData.task}
          className="task_input"
          placeholder="Wpisz zadanie do zrobienia"
          onChange={handleChange}
        />

        <div className="task_form_bottom_line">
          <div>
            {/* tagi do dodawnia */}
            <Tag
              tagName="HTML"
              selectTag={selectTag}
              selected={checkTag("HTML")}
            />
            <Tag
              tagName="CSS"
              selectTag={selectTag}
              selected={checkTag("CSS")}
            />
            <Tag
              tagName="JavaScript"
              selectTag={selectTag}
              selected={checkTag("JavaScript")}
            />
            <Tag
              tagName="React"
              selectTag={selectTag}
              selected={checkTag("React")}
            />
          </div>

          <div>
            {/* wybor kolumny */}
            <select
              name="status"
              value={taskData.status}
              className="task_status"
              onChange={handleChange}
            >
              <option value="todo">Do zrobienia</option>
              <option value="doing">Robione</option>
              <option value="done">Zrobione</option>
            </select>
          
            <button type="submit" className="task_submit">
              + Dodaj zadanie
            </button>
          </div>
        </div>
      </form>
    </header>
  );
};


export default TaskForm;