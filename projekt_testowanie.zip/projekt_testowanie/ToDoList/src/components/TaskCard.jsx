import React from "react";

import "./TaskCard.css";
import Tag from "./Tag";

import deleteIcon from "../assets/delete.png";


const TaskCard = ({ title, tags, handleDelete, index }) => {
    return (
        //karta zadan
        <article className='task_card'>
            {/* Wyświetlanie tytułu zadania */}
            <p className='task_text'>{title}</p>

            {/* karta z dolnymi rzeczmi/usuwanie i tagi */}
            <div className='task_card_bottom_line'>
               {/* wybieranie tagow */}
                <div className='task_card_tags'>
                    {tags.map((tag, index) => (
                        // Renderowanie Tag dla wszystkih 
                        <Tag key={index} tagName={tag} selected />
                    ))}
                </div>
               {/* usuwanie (ikona) */}
                <div
                    className='task_delete'
                    onClick={() => handleDelete(index)}>
                    <img src={deleteIcon} className='delete_icon' alt='' />
                </div>
            </div>
        </article>
    );
};


export default TaskCard;