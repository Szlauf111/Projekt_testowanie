import React from "react";
import ReactDOM from "react-dom/client";

import App from "./App.jsx";
import "./index.css";

// Glowny element reactu
ReactDOM.createRoot(document.getElementById("root")).render(
    // wykrywanie potencjalnych bledow
    <React.StrictMode>
        <App />
    </React.StrictMode>
);
